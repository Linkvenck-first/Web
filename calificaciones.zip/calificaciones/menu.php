	<header class="clearfix">
		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="pagina1.php">Calificaciones</a></li>
			</ul>
		</nav>

		<div class="derecha">
			<a href="cerrar_sesion.php">Cerrar Sesión</a>
		</div>		
	</header>
