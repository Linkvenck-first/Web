
<?php 
	require 'abre_sesion.php';
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Pagina 2</title>
 	<meta charset="utf-8">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet"> 	
 	<link rel="stylesheet" type="text/css" href="estilo.css">
 </head>
 <body>
 	<div class="contenedor">
		<?php require 'menu.php'; ?>
	 	<p>
	 		<h1>Pagina 2</h1>
	 	</p>
	 	<section>
	 		<p>
	 			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	 			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	 			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	 			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	 			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
	 			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	 		</p>
	 	</section>
 		
 	</div>
 
 </body>
 </html>