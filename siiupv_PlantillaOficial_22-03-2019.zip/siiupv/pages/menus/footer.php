<?php
define('RAIZ','/Web/siiupv/');
 ?>
<!-- Main Footer -->
<footer class="main-footer">
  <!-- To the right
  <div class="pull-right hidden-xs">
    Anything you want
  </div>
  -->
  <!-- Default to the left -->
  <div class="" align="center">
    <h1>Todo Derechocopia UPV SaCv</h1>
  </div>
</footer>

<!-- jQuery 3 -->
<script src="<?php echo RAIZ . 'bower_components/jquery/dist/jquery.min.js' ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo RAIZ . 'bower_components/bootstrap/dist/js/bootstrap.min.js' ?> "></script>
<!-- AdminLTE App -->
<script src="<?php echo RAIZ . 'dist/js/adminlte.min.js' ?> "></script>
